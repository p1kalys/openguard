# OpenGuard

A minimal TypeScript library for implementing guardrails around AI interactions to ensure safe and responsible usage.

## Installation

```bash
pnpm install openguard
```

## Usage

```typescript
import { OpenGuard, GuardrailConfig } from 'openguard';

// Initialize with default configuration
const guard = new OpenGuard();

// Or with custom configuration
const config: GuardrailConfig = {
  enabled: true,
  maxTokens: 1000,
  blockedPatterns: [/\b(password|secret)\b/i]
};
const customGuard = new OpenGuard(config);

// Validate input
const result = guard.validate("Hello, world!");
if (result.valid) {
  console.log("Input is safe");
} else {
  console.log("Input blocked:", result.reason);
}

// Update configuration
guard.updateConfig({ maxTokens: 500 });
```

## Features

- Input validation against configurable rules
- Pattern-based content filtering
- Token limit enforcement
- Runtime configuration updates

## Development

```bash
# Install dependencies
pnpm install

# Build the project
pnpm build

# Watch mode for development
pnpm dev
```

## License

MIT
